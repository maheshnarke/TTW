package com.m2.constants;

public class TTWConstants {
	public static final String LOG_TAG = "TTW";
	public static final String PLACES_API_BASE = "https://maps.googleapis.com/maps/api/place";
	public static final String TYPE_AUTOCOMPLETE = "/autocomplete";
	public static final String OUT_JSON = "/json";
	public static final String API_KEY = "AIzaSyD8pGqJtnNSDibTUVPNIhhZKhZskf9mvb8";
	public static final String PROJECT_ID="our-reason-865";
	public static final String PROJECT_NAME="TagItToWinIt";
	public static final String SHA1="58:EC:5E:B1:AE:5A:E3:84:89:B4:D6:DC:FD:77:F3:21:96:7C:57:1D;com.com.m2.tagittowinit";
	
}
