/** Automatically generated file. DO NOT MODIFY */
package com.m2.tagittowinit;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}